import { Strapi } from '@strapi/strapi';

export default {
  register({ strapi }: { strapi: Strapi }) {
    strapi.log.info('✅ Command Launcher registrato');
  },
  bootstrap({ strapi }: { strapi: Strapi }) {
    strapi.log.info('🚀 Command Launcher avviato');
  },
};
