export default {
  // Se servono metodi, mettili qui
};
