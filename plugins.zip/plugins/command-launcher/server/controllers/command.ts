import { Context } from 'koa';

export default {
  async execute(ctx: Context) {
    ctx.logger.info('Esecuzione comando avvenuta!');
    ctx.send({ success: true, message: 'Comando lanciato correttamente' });
  },
};
