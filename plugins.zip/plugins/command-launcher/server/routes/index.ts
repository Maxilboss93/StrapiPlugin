export default [
  {
    method: 'POST',
    path: '/execute',
    handler: 'command.execute',
    config: {
      policies: [],
    },
  },
];
