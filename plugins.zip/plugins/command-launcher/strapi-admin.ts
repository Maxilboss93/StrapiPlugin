import admin from './admin/src';
export default admin;
