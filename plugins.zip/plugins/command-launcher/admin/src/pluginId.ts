const pluginId = 'command-launcher';
export default pluginId;
