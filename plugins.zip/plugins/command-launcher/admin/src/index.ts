import pluginPkg from '../../package.json';
import pluginId from './pluginId';
import PluginIcon from './components/PluginIcon';
import HomePage from './pages/HomePage';

export default {
  register(app: any) {
    app.addMenuLink({
      to: `/plugins/${pluginId}`,
      icon: PluginIcon,
      intlLabel: {
        id: `${pluginId}.plugin.name`,
        defaultMessage: 'Command Launcher',
      },
      Component: HomePage,
      permissions: [],
    });
  },
  bootstrap() {},
  async registerTrads() {
    return [];
  },
};
