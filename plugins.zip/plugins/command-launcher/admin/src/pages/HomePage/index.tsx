import React from 'react';
import { Button } from '@strapi/design-system/Button';
import { request } from '@strapi/helper-plugin';
import { Box } from '@strapi/design-system/Box';
import { Typography } from '@strapi/design-system/Typography';

const HomePage = () => {
  const handleClick = async () => {
    try {
      await request('/command-launcher/execute', { method: 'POST' });
      strapi.notification.success('Comando eseguito!');
    } catch (err) {
      strapi.notification.error('Errore durante l\'esecuzione.');
    }
  };

  return (
    <Box padding={8} background="neutral100">
      <Typography variant="alpha">Lancia il comando</Typography>
      <Box paddingTop={4}>
        <Button onClick={handleClick}>Esegui</Button>
      </Box>
    </Box>
  );
};

export default HomePage;
