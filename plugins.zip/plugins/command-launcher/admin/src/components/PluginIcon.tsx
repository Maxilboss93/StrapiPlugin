import React from 'react';
import Rocket from '@strapi/icons/Rocket';

const PluginIcon = () => <Rocket />;

export default PluginIcon;
